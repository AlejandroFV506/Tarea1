﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Tarea_What;

public class ChatClient
{
    private TcpClient client;
    private NetworkStream ComuniServer;
    private Thread listenerThread;
    private Form1 form;

    public ChatClient(string ipAddress, int port, Form1 form)
    {
        client = new TcpClient();
        client.Connect(ipAddress, port);
        ComuniServer = client.GetStream();
        this.form = form;
        Console.WriteLine("Conectado al servidor en " + ipAddress + ":" + port);
    }

    public void Start()
    {
        listenerThread = new Thread(new ThreadStart(RecibirMSJ));
        listenerThread.Start();
    }

    public void EnviarMSJ(string message)
    {
        byte[] buffer = Encoding.ASCII.GetBytes(message);
        ComuniServer.Write(buffer, 0, buffer.Length);
        ComuniServer.Flush();
    }

    private void RecibirMSJ()
    {
        byte[] buffer = new byte[4096];
        int bytesRead;

        while (true)
        {
            bytesRead = 0;

            try
            {
                bytesRead = ComuniServer.Read(buffer, 0, 4096);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0)
                break;

            string ServerMSJ = Encoding.ASCII.GetString(buffer, 0, bytesRead);
            form.ActualizarChat(ServerMSJ);
        }
    }
}
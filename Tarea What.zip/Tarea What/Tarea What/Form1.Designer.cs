﻿namespace Tarea_What
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSend = new Button();
            label1 = new Label();
            txtMessage = new TextBox();
            label3 = new Label();
            txtChat = new TextBox();
            NombreTxt = new TextBox();
            labelUserName = new Label();
            SuspendLayout();
            // 
            // btnSend
            // 
            btnSend.Location = new Point(54, 577);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(212, 66);
            btnSend.TabIndex = 0;
            btnSend.Text = "Enviar";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(40, 125);
            label1.Name = "label1";
            label1.Size = new Size(130, 20);
            label1.TabIndex = 1;
            label1.Text = "Redactar mensaje:";
            label1.Click += label1_Click;
            // 
            // txtMessage
            // 
            txtMessage.Location = new Point(45, 178);
            txtMessage.Multiline = true;
            txtMessage.Name = "txtMessage";
            txtMessage.Size = new Size(233, 366);
            txtMessage.TabIndex = 4;
            txtMessage.TextChanged += textBox2_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(316, 37);
            label3.Name = "label3";
            label3.Size = new Size(138, 20);
            label3.TabIndex = 5;
            label3.Text = "Mensajes entrantes:";
            label3.Click += label3_Click;
            // 
            // txtChat
            // 
            txtChat.Location = new Point(316, 96);
            txtChat.Multiline = true;
            txtChat.Name = "txtChat";
            txtChat.Size = new Size(241, 517);
            txtChat.TabIndex = 6;
            txtChat.TextChanged += textBox3_TextChanged;
            // 
            // txtUserName
            // 
            NombreTxt.Location = new Point(40, 71);
            NombreTxt.Name = "txtUserName";
            NombreTxt.Size = new Size(204, 27);
            NombreTxt.TabIndex = 7;
            // 
            // labelUserName
            // 
            labelUserName.AutoSize = true;
            labelUserName.Location = new Point(40, 37);
            labelUserName.Name = "labelUserName";
            labelUserName.Size = new Size(67, 20);
            labelUserName.TabIndex = 8;
            labelUserName.Text = "Nombre:";
            labelUserName.Click += labelUserName_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(586, 666);
            Controls.Add(labelUserName);
            Controls.Add(NombreTxt);
            Controls.Add(txtChat);
            Controls.Add(label3);
            Controls.Add(txtMessage);
            Controls.Add(label1);
            Controls.Add(btnSend);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSend;
        private Label label1;
        private TextBox txtMessage;
        private Label label3;
        private TextBox txtChat;
        private TextBox NombreTxt;
        private Label labelUserName;
    }
}
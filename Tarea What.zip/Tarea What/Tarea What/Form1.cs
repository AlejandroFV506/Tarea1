using System;
using System.Windows.Forms;

namespace Tarea_What
{
    public partial class Form1 : Form
    {
        private ChatClient client;
        private string NombreCLient;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Conectamos al cliente al servidor en el puerto fijo 5000
            client = new ChatClient("127.0.0.1", 5000, this);
            client.Start();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (client == null)
            {
                MessageBox.Show("No se ha podido conectar al servidor.");
                return;
            }

            if (string.IsNullOrWhiteSpace(NombreTxt.Text))
            {
                MessageBox.Show("Por favor, ingresa tu nombre.");
                return;
            }

            if (NombreCLient == null)
            {
                NombreCLient = NombreTxt.Text;
            }

            string message = NombreTxt.Text;
            string formattedMessage = $"{NombreCLient}: {message}";
            client.EnviarMSJ(formattedMessage);
            ActualizarChat("Yo: " + message);
            txtMessage.Clear();
        }

        public void ActualizarChat(string message)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(ActualizarChat), new object[] { message });
                return;
            }
            txtChat.AppendText(message + Environment.NewLine);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void labelUserName_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;

class ServerProgram
{
    static void Main(string[] args)
    {
        ChatServer server = new ChatServer(5000);
        server.Start();
    }
}

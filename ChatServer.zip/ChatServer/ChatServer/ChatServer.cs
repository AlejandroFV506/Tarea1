﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Collections.Generic;

public class ChatServer
{
    private TcpListener listener;
    private List<ClientHandler> cliente;
    private bool Funciona;

    public ChatServer(int port)
    {
        listener = new TcpListener(IPAddress.Any, port);
        cliente = new List<ClientHandler>();
    }

    public void Start()
    {
        listener.Start();
        Funciona = true;
        Console.WriteLine("El servidor se inicio en el Puerto: " + ((IPEndPoint)listener.LocalEndpoint).Port);

        while (Funciona)
        {
            TcpClient client = listener.AcceptTcpClient();
            ClientHandler clientHandler = new ClientHandler(client, this);
            cliente.Add(clientHandler);

            Thread clientThread = new Thread(new ThreadStart(clientHandler.ComuniClient));
            clientThread.Start();
        }
    }

    public void Trasmitir(string message, ClientHandler sender)
    {
        byte[] buffer = Encoding.ASCII.GetBytes(message);

        foreach (var client in cliente)
        {
            if (client != sender)
            {
                client.EnvioMSJ(buffer);
            }
        }
    }

    public void CerrarClient(ClientHandler clientHandler)
    {
        cliente.Remove(clientHandler);
    }
}

public class ClientHandler
{
    private TcpClient tcpClient;
    private ChatServer server;
    private NetworkStream clientStream;

    public ClientHandler(TcpClient client, ChatServer server)
    {
        tcpClient = client;
        this.server = server;
        clientStream = tcpClient.GetStream();
    }

    public void ComuniClient()
    {
        byte[] message = new byte[4096];
        int bytesRead;

        while (true)
        {
            bytesRead = 0;

            try
            {
                bytesRead = clientStream.Read(message, 0, 4096);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0)
                break;

            string MSJenviado = Encoding.ASCII.GetString(message, 0, bytesRead);
            Console.WriteLine("Cliente: " + MSJenviado);

            server.Trasmitir(MSJenviado, this);
        }

        server.CerrarClient(this);
        tcpClient.Close();
    }

    public void EnvioMSJ(byte[] message)
    {
        clientStream.Write(message, 0, message.Length);
        clientStream.Flush();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Cliente {
    private static final String HOST = "localhost";
    private static final int PUERTO = 8090;
    private static int contadorClientes = 1; 
    private Socket socket;
    private PrintWriter salida;
    private BufferedReader entrada;
    private VentanaUsuario ventana;
    private String nombreJugador; 

    public Cliente() {
        try {
            socket = new Socket(HOST, PUERTO);
            salida = new PrintWriter(socket.getOutputStream(), true);
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        nombreJugador = "Jugador" + contadorClientes;
        contadorClientes++;

        ventana = new VentanaUsuario(salida, nombreJugador);

        new Thread(this::escucharServidor).start();
    }

    private void escucharServidor() {
        try {
            String mensaje;
            while ((mensaje = entrada.readLine()) != null) {
                procesarMensaje(mensaje);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void procesarMensaje(String mensaje) {
        System.out.println("Mensaje del servidor: " + mensaje);
        String[] partes = mensaje.split(" ");
        if (partes[0].equals("ACTUALIZAR")) {
            int x = Integer.parseInt(partes[1]);
            int y = Integer.parseInt(partes[2]);
            Celda.Tipo tipo = Celda.Tipo.valueOf(partes[3]);
            ventana.actualizarCelda(x, y, tipo);
        } else if (partes[0].equals("BARCO")) {
            int posXBarco = Integer.parseInt(partes[1]);
            int posYBarco = Integer.parseInt(partes[2]);
            ventana.actualizarBarco(posXBarco, posYBarco);
        } else if (partes[0].equals("CHAT")) {
            String nombreJugador = partes[1];
            StringBuilder mensajeChat = new StringBuilder();
            for (int i = 2; i < partes.length; i++) {
                mensajeChat.append(partes[i]).append(" ");
            }
            ventana.actualizarChat(nombreJugador, mensajeChat.toString().trim());
        }
    }


    public static void main(String[] args) {
        new Cliente();
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
import javax.swing.*;
import java.awt.*;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.net.*;

public class Servidor {
    private static final int PUERTO = 8090;
    private static List<ClienteHandler> clientes = Collections.synchronizedList(new ArrayList<>());
    private static Tablero tablero;
    private static JFrame ventanaTablero;

    public static void main(String[] args) throws IOException {
        ServerSocket servidor = new ServerSocket(PUERTO);
        System.out.println("Servidor iniciado en el puerto " + PUERTO);

        tablero = new Tablero();
        tablero.generarTablero(); // Generar el tablero aleatorio

        // Crear y mostrar la ventana del tablero
        crearVentanaTablero();

        while (true) {
            try {
                Socket clienteSocket = servidor.accept();
                ClienteHandler clienteHandler = new ClienteHandler(clienteSocket, tablero);
                clientes.add(clienteHandler);
                new Thread(clienteHandler).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static synchronized void enviarATodos(String mensaje) {
        for (ClienteHandler cliente : clientes) {
            cliente.enviarMensaje(mensaje);
        }
    }

    public static synchronized void enviarACliente(ClienteHandler cliente, String mensaje) {
        cliente.enviarMensaje(mensaje);
    }

    public static synchronized void removerCliente(ClienteHandler cliente) {
        clientes.remove(cliente);
    }

    private static void crearVentanaTablero() {
        ventanaTablero = new JFrame("Estado del Tablero");
        ventanaTablero.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaTablero.setSize(600, 600);

        JPanel panelTablero = new JPanel(new GridLayout(tablero.getTAMANO(), tablero.getTAMANO()));
        for (int i = 0; i < tablero.getTAMANO(); i++) {
            for (int j = 0; j < tablero.getTAMANO(); j++) {
                JLabel etiqueta = new JLabel(" ");
                etiqueta.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                etiqueta.setPreferredSize(new Dimension(30, 30));
                panelTablero.add(etiqueta);
            }
        }

        ventanaTablero.add(panelTablero);
        ventanaTablero.setVisible(true);
    }

    public static void actualizarVentanaTablero() {
        JPanel panelTablero = (JPanel) ventanaTablero.getContentPane().getComponent(0);
        for (int i = 0; i < tablero.getTAMANO(); i++) {
            for (int j = 0; j < tablero.getTAMANO(); j++) {
                JLabel etiqueta = (JLabel) panelTablero.getComponent(i * tablero.getTAMANO() + j);
                etiqueta.setText(tablero.getCelda(i, j).getTipo().name().substring(0, 1));
            }
        }
    }
}

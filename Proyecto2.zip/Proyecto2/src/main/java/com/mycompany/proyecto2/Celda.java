/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
public class Celda {
    public enum Tipo {
        VACIA, TESORO, AMENAZA, MERCADO
    }

    private Tipo tipo;

    public Celda() {
        this.tipo = Tipo.VACIA;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
}
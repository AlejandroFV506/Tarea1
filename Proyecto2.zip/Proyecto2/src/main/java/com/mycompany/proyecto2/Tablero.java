/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
import java.util.Random;

public class Tablero {
    private static final int TAMANO = 20;
    private Celda[][] celdas;

    public Tablero() {
        celdas = new Celda[TAMANO][TAMANO];
    }

    public void generarTablero() {
        Random random = new Random();
        // Generar celdas vacías, tesoros, amenazas y mercados
        for (int i = 0; i < TAMANO; i++) {
            for (int j = 0; j < TAMANO; j++) {
                celdas[i][j] = new Celda();
                int tipo = random.nextInt(100);
                if (tipo < 70) {
                    celdas[i][j].setTipo(Celda.Tipo.VACIA);
                } else if (tipo < 80) {
                    celdas[i][j].setTipo(Celda.Tipo.TESORO);
                } else if (tipo < 90) {
                    celdas[i][j].setTipo(Celda.Tipo.AMENAZA);
                } else {
                    celdas[i][j].setTipo(Celda.Tipo.MERCADO);
                }
            }
        }
    }
    
    public void mostrarTablero() {
        for (int i = 0; i < TAMANO; i++) {
            for (int j = 0; j < TAMANO; j++) {
                System.out.print(celdas[i][j].getTipo().name().charAt(0) + " "); // Mostrar el primer carácter del tipo de celda
            }
            System.out.println(); // Nueva línea para la siguiente fila
        }
    }

    // Métodos para obtener y actualizar el estado del tablero
    public Celda getCelda(int x, int y) {
        return celdas[x][y];
    }
    
    public int getTAMANO() {
        return TAMANO;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
import java.io.*;
import java.net.*;
import java.util.*;

public class ClienteHandler implements Runnable {
    private Socket clienteSocket;
    private PrintWriter salida;
    private BufferedReader entrada;
    private Tablero tablero;

    public ClienteHandler(Socket socket, Tablero tablero) throws IOException {
        this.clienteSocket = socket;
        this.tablero = tablero;
        this.salida = new PrintWriter(clienteSocket.getOutputStream(), true);
        this.entrada = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
    }

    @Override
    public void run() {
        try {
            String mensaje;
            while ((mensaje = entrada.readLine()) != null) {
                procesarMensaje(mensaje);
            }
        } catch (SocketException e) {
            System.out.println("Conexión con cliente reseteada: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clienteSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Servidor.removerCliente(this);
        }
    }

    private void procesarMensaje(String mensaje) {
        // Aquí se procesa el mensaje recibido del cliente y se actualiza el estado del juego
        System.out.println("Mensaje recibido: " + mensaje);
        // Actualizar el tablero o el estado del juego basado en el mensaje

        // Enviar actualizaciones de vuelta al cliente
        // Por ejemplo:
        Servidor.enviarATodos("Actualización de juego...");

        // Verificar si el mensaje es de chat y enviarlo a todos los clientes
        if (mensaje.startsWith("CHAT")) {
            Servidor.enviarATodos(mensaje);
        }
    }

    public void enviarMensaje(String mensaje) {
        salida.println(mensaje);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
public class Proyecto2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

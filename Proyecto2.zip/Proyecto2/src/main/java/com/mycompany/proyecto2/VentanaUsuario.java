/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto2;

/**
 *
 * @author jose1
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class VentanaUsuario extends JFrame {
    private static final int TAMANO_TABLERO = 20;
    private static final int ANCHO_CELDA = 30;
    private JPanel panelTablero;
    private Celda[][] celdas;
    private PrintWriter salida;
    private JLabel[][] etiquetasCeldas;
    private JLabel etiquetaBarco;
    private JTextArea chatArea;
    private JTextField chatInput;

    public VentanaUsuario(PrintWriter salida, String nombreJugador) {
        this.salida = salida;
        celdas = new Celda[TAMANO_TABLERO][TAMANO_TABLERO];
        etiquetasCeldas = new JLabel[TAMANO_TABLERO][TAMANO_TABLERO];
        for (int i = 0; i < TAMANO_TABLERO; i++) {
            for (int j = 0; j < TAMANO_TABLERO; j++) {
                celdas[i][j] = new Celda();
            }
        }

        setTitle("Caza del Tesoro - "+ nombreJugador);
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel para el tablero
        panelTablero = new JPanel(new GridLayout(TAMANO_TABLERO, TAMANO_TABLERO));
        inicializarTablero();
        add(panelTablero, BorderLayout.CENTER);

        // Panel para el chat
        JPanel panelChat = new JPanel(new BorderLayout());
        chatArea = new JTextArea(10, 20);
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        panelChat.add(scrollPane, BorderLayout.CENTER);
        chatInput = new JTextField(20);
        chatInput.addActionListener(e -> enviarMensajeChat());
        panelChat.add(chatInput, BorderLayout.SOUTH);
        add(panelChat, BorderLayout.EAST);

        setVisible(true);
    }

    private void inicializarTablero() {
        for (int i = 0; i < TAMANO_TABLERO; i++) {
            for (int j = 0; j < TAMANO_TABLERO; j++) {
                JPanel panel = new JPanel();
                panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                JLabel etiqueta = new JLabel();
                etiqueta.setPreferredSize(new Dimension(ANCHO_CELDA, ANCHO_CELDA));
                panel.add(etiqueta);
                panelTablero.add(panel);
                etiquetasCeldas[i][j] = etiqueta;
            }
        }
        etiquetaBarco = new JLabel("B");
        etiquetaBarco.setForeground(Color.RED);
        etiquetaBarco.setHorizontalAlignment(SwingConstants.CENTER);
        panelTablero.add(etiquetaBarco);
    }

    private void enviarMensajeChat() {
        String mensaje = chatInput.getText();
        salida.println("CHAT " + mensaje);
        chatInput.setText("");
    }

    // Métodos para actualizar la interfaz gráfica

    public void actualizarCelda(int x, int y, Celda.Tipo tipo) {
        celdas[x][y].setTipo(tipo);
        actualizarTablero();
    }

    public void actualizarBarco(int x, int y) {
        etiquetaBarco.setLocation(x * ANCHO_CELDA, y * ANCHO_CELDA);
    }
    
        public void actualizarChat(String nombreJugador, String mensaje) {
        chatArea.append(nombreJugador + ": " + mensaje + "\n");
    }
        
    private void actualizarTablero() {
        for (int i = 0; i < TAMANO_TABLERO; i++) {
            for (int j = 0; j < TAMANO_TABLERO; j++) {
                Celda.Tipo tipo = celdas[i][j].getTipo();
                String texto = "";
                switch (tipo) {
                    case VACIA:
                        texto = " ";
                        break;
                    case TESORO:
                        texto = "T";
                        break;
                    case AMENAZA:
                        texto = "A";
                        break;
                    case MERCADO:
                        texto = "M";
                        break;
                }
                etiquetasCeldas[i][j].setText(texto);
            }
        }
    }
}
